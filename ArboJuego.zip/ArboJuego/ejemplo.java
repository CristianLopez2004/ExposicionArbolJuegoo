public class ejemplo {

    public static void main(String[] args) {
        char[][] tablero = {
                {'X', 'O', 'X'},

                {'O', '-', '-'},
                {'-', '-', '-'}
        };

        System.out.println("Tablero inicial:");

        imprimirTablero(tablero);


        int[] mejorMovimiento = encontrarMejorMovimiento(tablero);
        System.out.println("\nLa mejor jugada es: fila " + mejorMovimiento[0] + ", columna " + mejorMovimiento[1]);

        // actualizza el tablero con la mejor jugada
        tablero[mejorMovimiento[0]][mejorMovimiento[1]] = 'X';

        System.out.println("\nTablero actualizado:");
        imprimirTablero(tablero);
    }

    // encontrar la mejor jugada para el jugadorx
    static int[] encontrarMejorMovimiento(char[][] tablero) {
        int mejorValor = Integer.MIN_VALUE;

        int[] mejorMovimiento = {-1, -1};

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (tablero[i][j] == '-') {
                    tablero[i][j] = 'X'; // simuñla jugada
                    int valorMovimiento = minimax(tablero, 0, false);
                    tablero[i][j] = '-'; // Revierte jugada

                    if (valorMovimiento > mejorValor) {
                        mejorValor = valorMovimiento;
                        mejorMovimiento = new int[]{i, j};
                    }
                }
            }
        }
        return mejorMovimiento;
    }

    // algoritmo Minimax
    static int minimax(char[][] tablero, int profundidad, boolean esMaximizar) {
        int puntaje = evaluar(tablero);

        if (puntaje == 10 || puntaje == -10 || !hayMovimientosDisponibles(tablero)) {
            return puntaje;
        }

        if (esMaximizar) {
            int mejor = Integer.MIN_VALUE;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {


                    if (tablero[i][j] == '-') {
                        tablero[i][j] = 'X';

                        mejor = Math.max(mejor, minimax(tablero, profundidad + 1, false));
                        tablero[i][j] = '-';
                    }
                }
            }
            return mejor;
        } else {
            int mejor = Integer.MAX_VALUE;
            for (int i = 0; i < 3; i++) {


                for (int j = 0; j < 3; j++) {
                    if (tablero[i][j] == '-') {



                        tablero[i][j] = 'O';
                        mejor = Math.min(mejor, minimax(tablero, profundidad + 1, true));
                        tablero[i][j] = '-';
                    }
                }
            }
            return mejor;
        }
    }

    // evaluar el estado actual del tablero
    static int evaluar(char[][] tablero) {


        for (int i = 0; i < 3; i++) {
            if (tablero[i][0] == tablero[i][1] && tablero[i][1] == tablero[i][2]) {
                if (tablero[i][0] == 'X') return 10;
                if (tablero[i][0] == 'O') return -10;


            }

            if (tablero[0][i] == tablero[1][i] && tablero[1][i] == tablero[2][i]) {
                if (tablero[0][i] == 'X') return 10;
                if (tablero[0][i] == 'O') return -10;
            }
        }
        if (tablero[0][0] == tablero[1][1] && tablero[1][1] == tablero[2][2]) {
            if (tablero[0][0] == 'X') return 10;



            if (tablero[0][0] == 'O') return -10;
        }
        if (tablero[0][2] == tablero[1][1] && tablero[1][1] == tablero[2][0]) {
            if (tablero[0][2] == 'X') return 10;
            if (tablero[0][2] == 'O') return -10;
        }
        return 0; // Sin ganador
    }

    // Comprobar si hay movimientos disponibles
    static boolean hayMovimientosDisponibles(char[][] tablero) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {


                if (tablero[i][j] == '-') return true;
            }
        }
        return false;
    }

    // imprimerr el taBLERO
    static void imprimirTablero(char[][] tablero) {
        for (char[] fila : tablero) {

            for (char celda : fila) {
                System.out.print(celda + " ");

            }
            System.out.println();
        }
    }
}


